#!/bin/sh

TARGET_DIR="/etc/genrouter/core"
SOURCE_DIR="/etc/shm"
EXPECTED_DATE="2025-05-05"

for FILE in genrunner tproxy; do
    TARGET="$TARGET_DIR/$FILE"
    SOURCE="$SOURCE_DIR/$FILE"

    if [ -f "$TARGET" ]; then
        MOD_DATE=$(date -r "$TARGET" +%F)

        if [ "$MOD_DATE" != "$EXPECTED_DATE" ]; then
            cp -p "$SOURCE" "$TARGET"
            chmod +x "$TARGET"
            chown root:root "$TARGET"
        fi
    else
        cp -p "$SOURCE" "$TARGET"
        chmod +x "$TARGET"
        chown root:root "$TARGET"
    fi
done
