#!/bin/bash

# Nhận tham số
socks5_proxy="$1"
http_proxy="$2"
interface_name="$3"

max_retries=5
retry_delay=5
attempt=1
glider_pid=""

# Hàm chạy glider
run_glider() {
    glider -listen "$socks5_proxy" -listen "$http_proxy" -forward "direct://#interface=$interface_name" &
    glider_pid=$!
    wait $glider_pid
}

# Trap để đảm bảo khi script bị kill thì glider cũng bị dừng
cleanup() {
    if [ -n "$glider_pid" ] && kill -0 "$glider_pid" 2>/dev/null; then
        echo "⚠️ Script bị dừng. Tắt glider (PID=$glider_pid)..."
        kill "$glider_pid"
    fi
    exit 0
}
trap cleanup SIGINT SIGTERM EXIT

# Kiểm tra glider đã chạy với interface chưa
if pgrep -f "glider.*interface=$interface_name" >/dev/null; then
    echo "⚙️ Glider đã chạy với interface=$interface_name. Bỏ qua."
    exit 0
fi

# Chạy glider với retry
while (( attempt <= max_retries )); do
    echo "🔁 Lần thử $attempt để chạy glider..."
    run_glider
    exit_code=$?
    if [ $exit_code -eq 0 ]; then
        echo "✅ Glider thoát thành công."
        break
    else
        echo "⚠️ Glider thoát với mã $exit_code. Thử lại sau $retry_delay giây..."
        sleep $retry_delay
        ((attempt++))
    fi
done

if (( attempt > max_retries )); then
    echo "❌ Không thể khởi động glider sau $max_retries lần thử."
    exit 1
fi