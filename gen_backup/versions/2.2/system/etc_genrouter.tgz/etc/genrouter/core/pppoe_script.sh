#!/bin/bash
RUN_GLIDER_BIN=/etc/genrouter/core/run_glider.sh

ACTION=$1
IFACE_DEVICE=$2
WAN_ID=$3
PPPOE_USERNAME=$4
PPPOE_PASSWORD=$5
SOCKS5_PROXY=$6
HTTP_PROXY=$7

DEVICE_NAME=dev_$WAN_ID
INTERFACE_NAME=if_$WAN_ID
PUBLIC_WAN_IF="wan"
extract_port() {
  echo "$1" | sed -E 's|.*:([0-9]+)$|\1|'
}

pppoe_start() {
  if ! uci get network.$DEVICE_NAME >/dev/null 2>&1; then
      uci set network.$DEVICE_NAME=device
      uci set network.$DEVICE_NAME.type=macvlan
      uci set network.$DEVICE_NAME.ifname=$IFACE_DEVICE
      uci set network.$DEVICE_NAME.mode=private
      uci set network.$DEVICE_NAME.name=$DEVICE_NAME
      echo "Device $DEVICE_NAME created"
      uci commit network
  else
      echo "Device $DEVICE_NAME exits"
  fi

  if ! uci get network.$INTERFACE_NAME >/dev/null 2>&1; then
      uci set network.$INTERFACE_NAME=interface
      uci set network.$INTERFACE_NAME.proto=pppoe
      uci set network.$INTERFACE_NAME.username=$PPPOE_USERNAME
      uci set network.$INTERFACE_NAME.password=$PPPOE_PASSWORD
      uci set network.$INTERFACE_NAME.device=$DEVICE_NAME
      uci set network.$INTERFACE_NAME.metric=20
      echo "Interface $INTERFACE_NAME created"
      uci commit network
  else
      echo "Interface $INTERFACE_NAME exits"
  fi

  is_up=$(ifstatus "$INTERFACE_NAME" | jsonfilter -e '@.up')
  is_pending=$(ifstatus "$INTERFACE_NAME" | jsonfilter -e '@.pending')
  if [ "$is_up" = "true" ] || [ "$is_pending" = "true" ]; then
      echo "✅ Interface $INTERFACE_NAME is already up or pending"
  else
      echo "🔁 Bringing up $INTERFACE_NAME..."
      ifup $INTERFACE_NAME >/dev/null 2>&1
  fi
  # check glider running
   # Kiểm tra glider đã chạy với interface này chưa
  if pgrep -f "run_glider.*pppoe-$INTERFACE_NAME" >/dev/null; then
      echo "⚙️ Glider is already running for $INTERFACE_NAME, skip starting."
  else
      echo "🚀 Starting glider for $INTERFACE_NAME..."
      $RUN_GLIDER_BIN "$SOCKS5_PROXY" "$HTTP_PROXY" "pppoe-$INTERFACE_NAME" >/dev/null 2>&1 &
  fi
}

pppoe_stop() {
  ifdown $INTERFACE_NAME
  if uci get network.$INTERFACE_NAME >/dev/null 2>&1; then
    uci del network.$INTERFACE_NAME
  fi
  if uci get network.$DEVICE_NAME >/dev/null 2>&1; then
    uci del network.$DEVICE_NAME
  fi
  uci commit network
  echo "🛑 Stopping glider for $INTERFACE_NAME..."
  pids=$(pgrep -f "run_glider.*pppoe-$INTERFACE_NAME")
  if [ -n "$pids" ]; then
      echo "🔎 Found glider PIDs: $pids"
      kill $pids && echo "✅ Glider stopped." || echo "❌ Failed to stop glider."
  else
      echo "ℹ️ No glider process found for $INTERFACE_NAME."
  fi
}

pppoe_reset(){
  if ! uci get network.$DEVICE_NAME >/dev/null 2>&1; then
      echo "Device $DEVICE_NAME not exits, can't reset"
      exit 1
  fi
  if ! uci get network.$INTERFACE_NAME >/dev/null 2>&1; then
      echo "Device $INTERFACE_NAME not exits, can't reset"
      exit 1
  fi
  is_up=$(ifstatus "$INTERFACE_NAME" | jsonfilter -e '@.up')
  is_pending=$(ifstatus "$INTERFACE_NAME" | jsonfilter -e '@.pending')
  if [ "$is_up" = "true" ] || [ "$is_pending" = "true" ]; then
      echo "✅ Interface $INTERFACE_NAME is already up or pending, need down"
      echo "🛑 Stopping glider for $INTERFACE_NAME..."
      pids=$(pgrep -f "run_glider.*pppoe-$INTERFACE_NAME")
      if [ -n "$pids" ]; then
          echo "🔎 Found glider PIDs: $pids"
          kill $pids && echo "✅ Glider stopped." || echo "❌ Failed to stop glider."
      else
          echo "ℹ️ No glider process found for $INTERFACE_NAME."
      fi
      ifdown $INTERFACE_NAME >/dev/null 2>&1
  fi
  sleep 1
  ifup $INTERFACE_NAME >/dev/null 2>&1
  # check glider running
  # Kiểm tra glider đã chạy với interface này chưa
  if pgrep -f "run_glider.*pppoe-$INTERFACE_NAME" >/dev/null; then
      echo "⚙️ Glider is already running for $INTERFACE_NAME, skip starting."
  else
      echo "🚀 Starting glider for $INTERFACE_NAME..."
      $RUN_GLIDER_BIN "$SOCKS5_PROXY" "$HTTP_PROXY" "pppoe-$INTERFACE_NAME" >/dev/null 2>&1 &
  fi
}


pppoe_update(){
  if ! uci get network.$DEVICE_NAME >/dev/null 2>&1; then
      echo "Device $DEVICE_NAME not exits, can't update"
      exit 1
  fi
  if ! uci get network.$INTERFACE_NAME >/dev/null 2>&1; then
      echo "Device $INTERFACE_NAME not exits, can't update"
      exit 1
  fi
  pids=$(pgrep -f "run_glider.*pppoe-$INTERFACE_NAME")
  if [ -n "$pids" ]; then
      echo "🔎 Found glider PIDs: $pids"
      kill $pids && echo "✅ Glider stopped." || echo "❌ Failed to stop glider."
  else
      echo "ℹ️ No glider process found for $INTERFACE_NAME."
  fi
  echo "🚀 Starting glider for $INTERFACE_NAME..."
  $RUN_GLIDER_BIN "$SOCKS5_PROXY" "$HTTP_PROXY" "pppoe-$INTERFACE_NAME" >/dev/null 2>&1 &
}

case "$ACTION" in
  start)
    pppoe_start
    ;;
  stop)
    pppoe_stop
    ;;
  reset)
    pppoe_reset
    ;;
  update)
    pppoe_update
    ;;
  *)
    echo "❓ Usage: $0 start|stop|reset|update <WAN_ID> <USER> <PASS> <SOCKS5_PROXY> <HTTP_PROXY>"
    exit 1
    ;;
esac
