#!/bin/sh
exec /etc/genrouter/server
