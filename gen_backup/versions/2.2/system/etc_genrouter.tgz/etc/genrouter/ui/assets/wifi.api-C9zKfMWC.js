import{i}from"./devices.api-BimB_a82.js";const e=r=>i.post("/api/router/create_wifi",{data:r});export{e as c};
