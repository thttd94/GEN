import{i}from"./devices.api-CXcAbjvr.js";const e=r=>i.post("/api/router/create_wifi",{data:r});export{e as c};
