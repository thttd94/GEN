import{i}from"./devices.api-DuPewIw8.js";const e=r=>i.post("/api/router/create_wifi",{data:r});export{e as c};
